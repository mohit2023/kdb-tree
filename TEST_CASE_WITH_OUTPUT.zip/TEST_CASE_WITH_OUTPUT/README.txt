d=2 (Dimentions)
l=3 (Maximum number of regions in a region node)
o=3 (Maximum number of points in a point node)